package net.codes;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class ContactsBD {
	
	public static void main(String[] args) {
		   
		SpringApplication.run(ContactsBD.class, args);
	}

}
