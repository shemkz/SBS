from django.apps import AppConfig


class IesAppConfig(AppConfig):
    name = 'ies_app'
