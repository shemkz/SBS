from django.apps import AppConfig


class DwhConfig(AppConfig):
    default_auto_field = 'django.db.models.BigAutoField'
    name = 'dwh'
