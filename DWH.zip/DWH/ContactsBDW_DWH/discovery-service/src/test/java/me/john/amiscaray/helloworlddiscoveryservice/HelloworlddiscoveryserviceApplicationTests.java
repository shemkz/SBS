package me.john.amiscaray.helloworlddiscoveryservice;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class HelloworlddiscoveryserviceApplicationTests {

    @Test
    void contextLoads() {
    }

}
