package me.john.amiscaray.helloservice;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class HelloserviceApplicationTests {

    @Test
    void contextLoads() {
    }

}
